package vendas;

import java.util.*;

public class Secretariado extends Colaborador {

	public Secretariado() {
	}

	private String horario;

}