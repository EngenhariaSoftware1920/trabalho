package vendas;

import java.util.*;

public class Assistente extends ElementoEquipa {

	public Assistente() {
	}

}