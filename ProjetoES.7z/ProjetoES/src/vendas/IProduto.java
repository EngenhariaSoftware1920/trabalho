package vendas;

import java.util.*;

public interface IProduto {

}