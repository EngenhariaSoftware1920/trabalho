package vendas;

import java.util.*;

public class GestaoColaborador {

	private GestaoColaborador() {
	}

	private ColaboradorFactory factory;

	private ArrayList<Colaborador> colaboradores;



}