package vendas;

import java.util.*;

public class GestaoServico {

	public GestaoServico() {
	}
	private ArrayList<TipoConsulta> tipoConsulta;

	private ArrayList<Operacao> operacao;

	private ArrayList<Intervencao> intervencao;




}