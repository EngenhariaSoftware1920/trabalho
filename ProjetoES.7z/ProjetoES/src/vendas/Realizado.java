package vendas;

import java.util.*;

public class Realizado {

	public Realizado() {
	}

}