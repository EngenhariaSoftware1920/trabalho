package vendas;

import java.util.*;

public class ProdutoVenda {

	public ProdutoVenda() {
	}

	private Produto produto;

	private Venda venda;

	private int quantidade;


}