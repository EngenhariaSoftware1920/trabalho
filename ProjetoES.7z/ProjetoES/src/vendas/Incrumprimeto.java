package vendas;

import java.time.LocalDate;
import java.util.*;

public class Incrumprimeto implements IState {

	public Incrumprimeto() {
	}

	private LocalDate dataPrevista;

}