package vendas;

import java.util.*;

public class Higiene extends Produto {

	public Higiene() {
	}

	private Genero genero;


}