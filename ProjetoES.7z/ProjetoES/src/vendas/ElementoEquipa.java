package vendas;

import java.util.*;

public class ElementoEquipa extends Colaborador {

	public ElementoEquipa() {
	}

	private boolean urgencias;



}