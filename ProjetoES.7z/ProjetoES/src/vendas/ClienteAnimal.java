package vendas;

import java.time.LocalDate;
import java.util.*;

public class ClienteAnimal {

	public ClienteAnimal() {
	}

	private Animal codAnimal;

	private LocalDate dataCompra;

	private LocalDate dataVenda;

	private Cliente codCliente;


}