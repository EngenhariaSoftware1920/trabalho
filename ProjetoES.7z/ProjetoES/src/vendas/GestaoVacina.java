package vendas;

import java.util.*;

public class GestaoVacina {

	private GestaoVacina() {
	}

	private ArrayList<Virus> virus;

	private ArrayList<Vacina> vacina;

	private ArrayList<VirusVacina> virusVacina;

	private ArrayList<VacinaEspecie> vacinaEspecie;





}