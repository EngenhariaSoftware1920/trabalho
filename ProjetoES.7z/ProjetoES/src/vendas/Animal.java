package vendas;

import java.time.LocalDate;
import java.util.*;

public class Animal {

	public Animal() {
	}

	private int codAnimal;

	private Veterinario veterinario;

	private Especie especie;

	private String sexo;

	private LocalDate dataNascimento;

	private ArrayList<String> antecClinicos;

	private ArrayList<ClienteAnimal> proprietarios;






}