package vendas;

import java.util.*;

public class Comida extends Produto {

	public Comida() {
	}

	private Genero genero;

	private ArrayList<Embalagem> embalagens;



}