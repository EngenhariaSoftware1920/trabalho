package vendas;

import java.util.*;

public interface IFactory {

}