package vendas;

import java.util.*;

public class GestaoCliente {

	public GestaoCliente() {
	}

	private ArrayList<Cliente> cliente;



}