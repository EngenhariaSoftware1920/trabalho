package vendas;

import java.time.LocalDate;
import java.util.*;

public class PorPagar implements IState {

	public PorPagar() {
	}

	private LocalDate dataMax;

}