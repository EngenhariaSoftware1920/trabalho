package vendas;

import java.util.*;

public class GestoProduto {

	public GestoProduto() {
	}

	private ProxyProduto proxy;


}