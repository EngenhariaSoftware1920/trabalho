package vendas;

import java.util.*;

public class Intervencao {

	public Intervencao() {
	}

	private Consulta consulta;

	private Operacao operacao;

	private ElementoEquipa equipa;





}