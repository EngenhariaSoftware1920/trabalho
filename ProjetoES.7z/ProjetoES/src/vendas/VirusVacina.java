package vendas;

import java.util.*;

public class VirusVacina {

	public VirusVacina() {
	}

	private Virus virus;

	private Vacina vacina;


}