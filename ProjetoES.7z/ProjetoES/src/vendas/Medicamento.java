package vendas;

import java.util.*;

public class Medicamento extends Produto {

	private Medicamento() {
	}

	private ArrayList<String> dosagem;

	private ArrayList<Embalagem> embalagens;

	private Genero genero;



}