package vendas;

import java.util.*;

public class TipoConsulta {

	public TipoConsulta() {
	}

	private String designacao;



}