package vendas;

import java.util.*;

public class GestaoAnimal {

	public GestaoAnimal() {
	}

	private ArrayList<Animal> animal;

	private ArrayList<Especie> especie;

	private ArrayList<EspecieVeterinario> especieVeterenario;

	private ArrayList<Genero> generos;





}