package vendas;

import java.util.*;

public interface IState {


}