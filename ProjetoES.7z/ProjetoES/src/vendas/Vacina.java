package vendas;

import java.util.*;

public class Vacina {

	public Vacina() {
	}

	private String nome;

	private String periodicidade;




}