package vendas;

import java.util.*;

public class Genero {

	public Genero() {
	}

	private String designacao;






}