package vendas;

import java.util.*;

public class Limpeza extends Colaborador {

	public Limpeza() {
	}

	private String horario;

}