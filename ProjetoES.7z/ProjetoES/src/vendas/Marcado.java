package vendas;

import java.util.*;

public class Marcado {

	public Marcado() {
	}

}