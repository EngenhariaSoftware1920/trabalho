package vendas;

import java.util.*;

public class Operacao {

	public Operacao() {
	}

	private String nome;




}