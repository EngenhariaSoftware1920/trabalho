package vendas;

import java.util.*;

public class EspecieVeterinario {

	public EspecieVeterinario() {
	}

	private Especie especie;

	private Veterinario veterinario;

	private String preferencia;


}