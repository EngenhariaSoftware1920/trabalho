package vendas;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class Consulta {

	public Consulta() {
	}

	private int codConsulta;

	private TipoConsulta tipo;

	private Animal animal;

	private LocalDate data;

	private LocalTime hora;

	private Veterinario medico;





}