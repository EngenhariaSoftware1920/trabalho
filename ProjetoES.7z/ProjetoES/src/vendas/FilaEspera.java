package vendas;

import java.util.*;

public class FilaEspera {

	public FilaEspera() {
	}

}