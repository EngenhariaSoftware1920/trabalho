package vendas;

import java.util.*;

public class Embalagem {

	public Embalagem() {
	}

	private String designacao;

	private float peso;





}