package vendas;

import java.util.*;

public class GestaoProduto {

	public GestaoProduto() {
	}

	private ProxyProduto proxy;



}