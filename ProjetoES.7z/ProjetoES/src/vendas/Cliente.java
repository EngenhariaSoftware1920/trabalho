package vendas;

import java.util.*;

public class Cliente {

	public Cliente() {
	}

	private int codCliente;

	private String nome;

	private String morada;

	private String telefone;

	private boolean proprietario;

	private ArrayList<ClienteAnimal> animais;





}