package vendas;

import java.util.*;

public class Virus {

	public Virus() {
	}

	private String nome;



}