package vendas;

import java.util.*;

public class ColaboradorFactory implements IFactory {

	public ColaboradorFactory() {
	}

	private static ColaboradorFactory single_instance;



}