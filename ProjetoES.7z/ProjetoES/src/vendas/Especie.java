package vendas;

import java.util.*;

public class Especie {

	public Especie() {
	}

	private String nome;

	private Genero genero;






}