package vendas;

import java.util.*;

public class Diverso {

	public Diverso() {
	}

	private String tipo;


}