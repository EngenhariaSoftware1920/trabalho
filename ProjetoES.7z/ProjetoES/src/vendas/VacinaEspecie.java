package vendas;

import java.util.*;

public class VacinaEspecie {

	public VacinaEspecie() {
	}

	private Vacina vacina;

	private Especie especie;


}