package vendas;

import java.time.LocalDate;
import java.util.*;

public class Pago implements IState {

	public Pago() {
	}

	private LocalDate data;

}