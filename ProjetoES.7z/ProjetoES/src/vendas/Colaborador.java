package vendas;

import java.util.*;

public abstract class Colaborador {

	public Colaborador() {
	}

	private String nome;

	private String morada;

	private String telefone;

	private String diaFolga;



}