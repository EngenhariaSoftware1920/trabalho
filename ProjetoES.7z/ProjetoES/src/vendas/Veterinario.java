package vendas;

import java.util.*;

public class Veterinario extends ElementoEquipa {

	public Veterinario() {
	}



}