package vendas;

import java.util.*;

public class GestaoVenda {

	public GestaoVenda() {
	}

	private ArrayList<Venda> venda;



}